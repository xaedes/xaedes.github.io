
# Manual Test Cases

Manual Test Cases that are not that easily carried out by automatic test.

## theme switch test

 - action: 
   - switch theme 
   - reload
 - expect:
   - the page shows in new theme

## preview test

 - action:
   - edit some page
   - input title, section, backquote, math equations, blockquote
   - click preview
 - expect:
   - preview should work

